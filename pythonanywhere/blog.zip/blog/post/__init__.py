# app中文
default_app_config='post.apps.PostConfig'


